echo Welcome to the PXS App Store!
echo You can download extra features here
echo Just enter the number of a choice and we will install it.
echo Available:
PS3='Choose: '
select app in fs mint host exit
do
 echo $app
 if [[ $app = "fs" ]];
 then
  touch fs.sh
  echo PS3='Option: ' >> fs.sh
  echo select fileo in exit mkdir >> fs.sh
  echo do >> fs.sh
  echo 'if [[ $fileo = "exit" ]];' >> fs.sh
  echo  exit >> fs.sh
  echo 'elif [[ $fileo = "mkdir" ]];' >> fs.sh 
  echo  read -p "Directory" dir >> fs.sh
  echo mkdir $dir >> fs.sh
  echo fi >> fs.sh
  echo done >> fs.sh 
  echo Installation succeeded.
 fi
done
