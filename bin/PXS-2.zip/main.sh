#OS
clear
bash  "PXDisk/sd\/OS/ROOT/runtime.sh"
source "PXDisk/sd\/OS/ROOT/coms/.bashrc"
cd "PXDisk/ud\/"
echo Type help for a list of commands.
while :; do
read -p "ud\>" cmd
$cmd
done
